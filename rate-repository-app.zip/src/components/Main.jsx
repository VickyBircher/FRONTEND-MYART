import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Publicaciones from './Publicaciones.jsx'
const Main = () => {

return(
    <>
    <View>
    <Publicaciones/>
    </View>
    </>
)

}
