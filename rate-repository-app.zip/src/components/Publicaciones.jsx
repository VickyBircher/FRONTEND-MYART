import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import constants from 'expo-constants'
import repositories from '../data/repositories.js'


const Publicaciones = () => {

return(
    <>
    <View>
<Text style={{marginTop: constants.statusBarHeight, flexGrow: 1}}> Hola mundo </Text>

    </View>
    </>
)

}
